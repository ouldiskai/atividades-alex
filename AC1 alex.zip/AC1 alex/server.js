const fs = require('fs')
const path = require('path')
const express = require('express')

const app = express();
const port = 3000;

const filmesPath = path.join(__dirname, 'filmes.json');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

let filmesData = fs.readFileSync(filmesPath, 'utf-8')
let filmes = JSON.parse(filmesData);

function salvarDados(filme) {
    fs.writeFileSync(filmesPath, JSON.stringify(filmes, null, 2));
}

app.get('/adicionar-fita', (req, res) => {
    res.sendFile(path.join(__dirname, 'adicionarfita.html'));
});

app.post('/adicionar-fita', (req, res) => {
    const novoFilme = req.body;

    if (filmes.find(filme => filme.nome.toLowerCase() === novoFilme.nome.toLowerCase())) {
        res.send('<h1>Fita já em estoque.</h1>')
        return;
    }
    filmes.push(novaFita);

    salvarDados();

    res.send('<h1>Filme adicionado com sucesso!</h1>')
});

app.get('/atualizar-fita', (req, res) => {
    res.sendFile(path.join(__dirname, 'atualizarfita.html'))

})
app.post('/atualizar-fita', (req, res) =>{
    const {nome, novaDescricao} = req.body;
    let filmesData = fs.readFileSync(filmesPath, 'utf-8')
    let filmes = JSON.parse(filmesData);
    
    const filmeIndex = filmes.findIndex(filme => filmes.nome.toLowerCase() === nome.toLowerCase());
    
    if (filmeIndex === -1) {
        res.send ('<h1>Filme não encontrado </h1>');
        return;
    }
    filmes[filmeIndex].desc = novaDescricao;

    salvarDados(filmes);

    res.send('<h1> Dados da fita atualizados com sucesso </h1>');
});

app.get('/retirar-fita', (req, res) => {
    res.sendFile(path.join(__dirname, 'retirarfita.html'));
})

app.post('retirar-fita', (req, res) => {
    const { nome } = req.body;

    let filmesData = fs.readFileSync(filmesPath, 'utf-8')
    let filmes = JSON.parse(filmesData);

    const filmeIndex = filmes.findIndex(filme => filme.nome.toLowerCase() === nome.toLowerCase());

    if (filmeIndex === -1) {
        res.send('<h1>Filme não encontrado</h1>');
        return;
    }

    res.send(`
    <script>
    if (confirm('Deseja excluir a fita ${nome}?')){
        window.location.href = '/fita-retirada?nome=${nome}'
    }
    else{
        window.locatio.href = '/retirar-fita';
    }
    </script>
    `)
})

app.get('/fita-retirada', (req, res) => {
    const nome = req.query.nome;

    let filmesData = fs.readFileSync(filmesPath, 'utf-8')
    let filmes = JSON.parse(filmesData);

    const filmeIndex = filme.findIndex(filme => filme.nome.toLowerCase() === nome.toLowerCase());

    filmes.splice(filmeIndex, 1);

    salvarDados(filmes);

    res.send(`<h1>A fita: ${nome} foi retirada com sucesso</h1>`);
});

app.listen(port, () => {
    console.log(`Servidor Iniciado em http://localhost:${port}`)
})